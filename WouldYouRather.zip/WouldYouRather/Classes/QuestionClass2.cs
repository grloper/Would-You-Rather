﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WouldYouRather.Classes
{
    public class QuestionClass2
    {
        protected string option2;
        public QuestionClass2(string option2)
        {
            this.option2 = option2;
        }

    }
}